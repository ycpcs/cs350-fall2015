// Comment to test individual method
#define ALL 1

// Uncomment to test individual method
//#define CONSTRUCTOR 1
//#define DESTRUCTOR 1
//#define INSERT 1
//#define FIND 1
//#define REMOVE 1
//#define LOADFACTOR 1
//#define MAXCHAINLENGTH 1
//#define NUMEMPTYSLOTS 1
