package edu.ycp.cs350.bintree;

/**
 * In-order binary tree traversal.
 */
public class InOrder implements Traversal {

	public void traverse(BinTreeNode node, BinTreeNodeVisitor visitor) {
		// TODO: implement
	}

}
