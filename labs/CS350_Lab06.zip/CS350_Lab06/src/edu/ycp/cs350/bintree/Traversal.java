package edu.ycp.cs350.bintree;

/**
 * Binary tree traversal.
 */
public interface Traversal {
	/**
	 * Traverse the binary tree whose root is given node,
	 * calling start(), visit(), and finish() on each node in
	 * the tree.
	 * 
	 * @param node    the root of the tree to traverse
	 * @param visitor the visitor to use to visit the tree nodes
	 */
	public void traverse(BinTreeNode node, BinTreeNodeVisitor visitor);
}
