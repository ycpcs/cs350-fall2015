package edu.ycp.cs350.bintree;

import java.util.Random;

/**
 * Create a "random" binary tree.
 */
public class MakeRandomTree {
	private static final int NUM_LEVELS = 5;

	private Random random = new Random();

	/**
	 * Return a "random" binary tree.
	 * 
	 * @param factory the factory to be used to create new binary tree nodes
	 * @return the root of the "random" binary tree
	 */
	public BinTreeNode createRandomTree(BinTreeNodeFactory factory) {
		return create(NUM_LEVELS, factory);
	}

	/**
	 * Create a part of a random binary tree.
	 * 
	 * @param numLevels the maximum number of tree levels to create 
	 * @param factory   the factory to be used to create new binary tree nodes
	 * @return the root of this part of the random binary tree,
	 *         or null if this part of the tree is empty
	 */
	private BinTreeNode create(int numLevels, BinTreeNodeFactory factory) {
		double prob = .5 + (.5 * ((double)(numLevels))/NUM_LEVELS);
		BinTreeNode node = null;
		if (numLevels > 0 && random.nextDouble() <= prob) {
			node = factory.create();
			node.setLeft(create(numLevels - 1, factory));
			node.setRight(create(numLevels - 1, factory));
		}
		return node;
	}
}
