package edu.ycp.cs350.bintree;

/**
 * Level-order binary tree traversal.
 */
public class LevelOrder implements Traversal {

	public void traverse(BinTreeNode node, BinTreeNodeVisitor visitor) {
		// TODO: implement
	}

}
