package edu.ycp.cs350.bintree;

/**
 * Visit a binary tree node during a tree traversal.
 */
public interface BinTreeNodeVisitor {
	/**
	 * Start the given node.
	 * This should be called when the traversal arrives at the node
	 * for the first time.
	 * 
	 * @param node the node being started
	 */
	public void start(BinTreeNode node);
	
	/**
	 * Visit the give node.
	 * Should be called after start(), and before finish().
	 * 
	 * @param node the node being visited
	 */
	public void visit(BinTreeNode node);
	
	/**
	 * Finish the given node.
	 * This should be called when the node is completely finished.
	 * 
	 * @param node the node being finished
	 */
	public void finish(BinTreeNode node);
}
