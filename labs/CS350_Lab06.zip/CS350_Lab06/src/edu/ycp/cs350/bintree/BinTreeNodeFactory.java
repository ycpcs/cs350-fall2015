package edu.ycp.cs350.bintree;

/**
 * Object that creates binary tree nodes.
 */
public interface BinTreeNodeFactory {
	/**
	 * Create a binary tree node.  The new node will have empty (null)
	 * left and right sub-trees.
	 * 
	 * @return the new binary tree node
	 */
	public BinTreeNode create();
}
