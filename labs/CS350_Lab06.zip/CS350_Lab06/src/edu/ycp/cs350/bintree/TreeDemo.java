package edu.ycp.cs350.bintree;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class TreeDemo extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private static final int FRAME_WIDTH = 800;
	private static final int FRAME_HEIGHT = 330;
	private static final int ANIM_DELAY = 300;

	private JPanel contentPane;
	private TreeCanvas treeCanvas;
	private JButton randomButton;
	private JComboBox<Object> traversalSelector;
	private JButton startButton;
	private Timer timer;
	
	private MakeRandomTree makeRandomTree;
	private Thread traversalThread;
	private long tick;
	
	public TreeDemo() {
		initialize();
		timer = new Timer(ANIM_DELAY, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				synchronized (TreeDemo.this) {
					++tick;
					TreeDemo.this.notify();
				}
			}
		});
		timer.start();
	}
	
	public void waitForTick() {
		synchronized (this) {
			long now = tick;
			while (tick <= now) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					// ignore
				}
			}
		}
	}
	
	private void initialize() {
		createContentPane();
		
		this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
		this.setResizable(false);
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) {// TODO Auto-generated method stub

				System.exit(0);
			}
		});
		this.setTitle("Binary Tree Demo");
		
		makeRandomTree = new MakeRandomTree();
		
		//treeCanvas.setRoot(makeRandomTree.createRandomTree(treeCanvas.getFactory()));
		
	}
	
	private JPanel createContentPane() {
		if (contentPane == null) {
			contentPane = new JPanel(null);
			createTreeCanvas();
			createRandomButton();
			createTraversalSelector();
			createStateButton();
			this.setContentPane(contentPane);
		}
		return contentPane;
	}
	
	private TreeCanvas createTreeCanvas() {
		if (treeCanvas == null) {
			treeCanvas = new TreeCanvas(this);
			treeCanvas.setBounds(5,5,780,230);
			
			contentPane.add(treeCanvas);
		}
		return treeCanvas;
	}
	
	private JButton createRandomButton() {
		if (randomButton == null) {
			randomButton = new JButton();
			randomButton.setBounds(5, 250, 90, 34);
			randomButton.setText("Random");
			randomButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					if (notRunning()) {
						treeCanvas.setRoot(makeRandomTree.createRandomTree(treeCanvas.getFactory()));
						treeCanvas.repaint();
					}
				}
			});
			
			contentPane.add(randomButton);
		}
		return randomButton;
	}
	
	private JComboBox<Object> createTraversalSelector() {
		if (traversalSelector == null) {
			traversalSelector = new JComboBox<Object>();
			traversalSelector.setBounds(100, 250, 120, 34);
			traversalSelector.addItem("Pre Order");
			traversalSelector.addItem("Post Order");
			traversalSelector.addItem("In Order");
			traversalSelector.addItem("Level Order");

			contentPane.add(traversalSelector);
		}
		return traversalSelector;
	}
	
	private JButton createStateButton() {
		if (startButton == null) {
			startButton = new JButton();
			startButton.setBounds(230, 250, 90, 34);
			startButton.setText("Start!");
			startButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					if (notRunning()) {
						startButton.setText("Running...");
						final String traversalType = traversalSelector.getSelectedItem().toString();
						if (traversalType == null) return;
						traversalThread = new Thread() {
							public void run() {
								Traversal traversal = null;
								if (traversalType.equals("Pre Order"))
									traversal = new PreOrder();
								else if (traversalType.equals("Post Order"))
									traversal = new PostOrder();
								else if (traversalType.equals("In Order"))
									traversal = new InOrder();
								else if (traversalType.equals("Level Order"))
									traversal = new LevelOrder();
								
								if (traversal != null) {
									treeCanvas.resetTree();
									traversal.traverse(treeCanvas.getRoot(), treeCanvas.getVisitor());
									
									SwingUtilities.invokeLater(new Runnable(){
										public void run() {
											notRunning();
										}
									});
								}
							}
						};
						traversalThread.start();
					}
				}
			});
			
			contentPane.add(startButton);
		}
		return startButton;
	}
	
	private boolean notRunning() {
		if (traversalThread == null)
			return true;
		
		if (!traversalThread.isAlive()) {
			traversalThread = null;
			startButton.setText("Start!");
			return true;
		}
		
		return false;
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable(){
			public void run() {
				TreeDemo treeDemo = new TreeDemo();
				treeDemo.setVisible(true);
			}
		});
	}
}
