package edu.ycp.cs350.bintree;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JPanel;

public class TreeCanvas extends JPanel {
	private static final long serialVersionUID = 1L;
	
	private static final int NODE_WIDTH = 30;
	private static final int ROW_GAP = 10;
	private static final Font LABEL_FONT = new Font("Serif", Font.BOLD, 20);
	private static final String LABEL_CHARS =
		"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!?";
	private static final float DARK_FACTOR = .6F;
	
	private enum State {
		INITIAL, STARTED, VISITED, FINISHED;
	}
	
	private class TreeCanvasNode implements BinTreeNode {
		private TreeCanvasNode left;
		private TreeCanvasNode right;
		private State state;
		private char label;
		
		public TreeCanvasNode(char label) {
			this.state = State.INITIAL;
			this.label = label;
		}
		
		public void setState(State state) {
			this.state = state;
		}
		
//		public State getState() {
//			return state;
//		}
		
		public char getLabel() {
			return label;
		}

		public void setLeft(BinTreeNode left) {
			this.left = (TreeCanvasNode) left;
		}

		public void setRight(BinTreeNode right) {
			this.right = (TreeCanvasNode) right;
		}

		public BinTreeNode getLeft() {
			return left;
		}

		public BinTreeNode getRight() {
			return right;
		}
		
		public void draw(Graphics g, Point location) {
			g.setColor(darkColor());
			g.fillOval(location.x - NODE_WIDTH/2, location.y - NODE_WIDTH/2, NODE_WIDTH+1, NODE_WIDTH+1);
			g.setColor(lightColor());
			g.drawOval(location.x - NODE_WIDTH/2, location.y - NODE_WIDTH/2, NODE_WIDTH, NODE_WIDTH);
			g.setFont(LABEL_FONT);
			g.drawString("" + getLabel(), location.x - 6, location.y +5);
		}
		
		private Color darkColor() {
			Color c = lightColor();
			return new Color(dark(c.getRed()), dark(c.getGreen()), dark(c.getBlue()));
		}
		
		private Color lightColor() {
			switch (state) {
			case INITIAL: return Color.LIGHT_GRAY;
			case STARTED: return Color.RED;
			case VISITED: return Color.GREEN;
			case FINISHED: return Color.BLUE;
			default:
				throw new IllegalStateException();
			}
		}
		
		private int dark(int value) {
			return (int)(DARK_FACTOR * value);
		}
		
	}
	
	private class TreeCanvasFactory implements BinTreeNodeFactory {
		private int nextLabel;
		
		public BinTreeNode create() {
			return new TreeCanvasNode(LABEL_CHARS.charAt(nextLabel++));
		}
		
		public void reset() {
			this.nextLabel = 0;
		}
	}
	
	private TreeDemo treeDemo;
	private BinTreeNode root;
	
	public TreeCanvas(TreeDemo treeDemo) {
		setBackground(Color.BLACK);
		
		this.treeDemo = treeDemo;
		this.root = null;
	}
	
	public TreeCanvasFactory getFactory() {
		return new TreeCanvasFactory();
	}
	
	public BinTreeNodeVisitor getVisitor() {
		return new BinTreeNodeVisitor() {
			public void start(BinTreeNode node) {
				TreeCanvasNode curNode =(TreeCanvasNode)node;
				curNode.setState(State.STARTED);
				TreeCanvas.this.repaint();
				treeDemo.waitForTick();
			}
			
			public void visit(BinTreeNode node) {
				TreeCanvasNode curNode =(TreeCanvasNode)node;
				curNode.setState(State.VISITED);
				TreeCanvas.this.repaint();
				treeDemo.waitForTick();
			}
			
			public void finish(BinTreeNode node) {
				TreeCanvasNode curNode =(TreeCanvasNode)node;
				curNode.setState(State.FINISHED);
				TreeCanvas.this.repaint();
				treeDemo.waitForTick();
			}
		};
	}
	
	public void setRoot(BinTreeNode root) {
		this.root = root;
	}
	
	public BinTreeNode getRoot() {
		return root;
	}
	
	public void resetTree() {
		resetTree(root);
		this.repaint();
	}

	private void resetTree(BinTreeNode node) {
		if (node == null) return;
		((TreeCanvasNode)node).setState(State.INITIAL);
		resetTree(node.getLeft());
		resetTree(node.getRight());
	}

	interface RenderNode {
		public void draw(Graphics g, BinTreeNode parent, Point parentLoc, BinTreeNode child, Point childLoc);
	}

	public void paint(Graphics g) {
		super.paint(g);
		int startX = getWidth() / 2;
		int startY = ROW_GAP + (NODE_WIDTH/2);
		render(g, null, null, root, new Point(startX, startY), getWidth()/2, new RenderNode(){
			public void draw(Graphics g, BinTreeNode parent, Point parentLoc, BinTreeNode child, Point childLoc) {
				if (parent != null) {
					g.setColor(Color.LIGHT_GRAY);
					g.drawLine(parentLoc.x, parentLoc.y, childLoc.x, childLoc.y);
				}
			}
		});
		render(g, null, null, root, new Point(startX, startY), getWidth()/2, new RenderNode(){
			public void draw(Graphics g, BinTreeNode parent, Point parentLoc, BinTreeNode child, Point childLoc) {
				((TreeCanvasNode)child).draw(g, childLoc);
			}
		});
	}
	
	private void render(
			Graphics g,
			BinTreeNode parent, Point parentLoc,
			BinTreeNode child, Point childLoc,
			int spacing,
			RenderNode callback) {
		
		if (child == null) return;
		
		callback.draw(g, parent, parentLoc, child, childLoc);
		int nextY = childLoc.y + (ROW_GAP+NODE_WIDTH);

		render(g, child, childLoc, child.getLeft(),
				new Point(childLoc.x - (spacing/2), nextY), spacing/2, callback);
		render(g, child, childLoc, child.getRight(),
				new Point(childLoc.x + (spacing/2), nextY), spacing/2, callback);
	}
}
