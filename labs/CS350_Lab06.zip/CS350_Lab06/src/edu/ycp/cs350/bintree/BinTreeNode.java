package edu.ycp.cs350.bintree;

/**
 * Node in a binary tree.
 */
public interface BinTreeNode {
	/** Set the left sub-tree. */
	public void setLeft(BinTreeNode left);
	
	/** Set the right sub-tree. */
	public void setRight(BinTreeNode right);
	
	/**
	 * Get the left sub-tree.
	 * @return the root of the left sub-tree, or null if the left sub-tree is empty.
	 */
	public BinTreeNode getLeft();

	/**
	 * Get the right sub-tree.
	 * @return the root of the right sub-tree, or null if the right sub-tree is empty.
	 */
	public BinTreeNode getRight();
}
