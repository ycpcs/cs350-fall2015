package edu.ycp.cs350.bintree;

/**
 * Post-order binary tree traversal.
 */
public class PostOrder implements Traversal {

	public void traverse(BinTreeNode node, BinTreeNodeVisitor visitor) {
		// TODO: implement
	}

}
