package edu.ycp.cs350.bintree;

/**
 * Pre-order binary tree traversal.
 */
public class PreOrder implements Traversal {

	public void traverse(BinTreeNode node, BinTreeNodeVisitor visitor) {
		// TODO: implement
	}

}
